// Header file for Function declarations

void swap(int, int);
void swap_by_pointers(int*, int*);
void reverse(int array[], int array_size);
